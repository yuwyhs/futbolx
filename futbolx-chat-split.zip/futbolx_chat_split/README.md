# FutbolX chat split

Copy this structure into the same GitHub repository as `live.html`:

```text
live.html
chat/
  loader.js
  chat.html
  chat.css
  chat.js
  emotes.js
  admin.html
  config.js
```

`live.html` now contains only a mount point for the chat. `chat/loader.js` fetches the separated chat/admin markup and then imports the chat engine.

Important: `config.js` contains the existing Supabase `anon` key, which is a public browser key. Do not put a Supabase `service_role` key here. The next step is to update `vercel.json`, `deno.json`, and `server.ts` so any privileged/server-side operations are protected.
